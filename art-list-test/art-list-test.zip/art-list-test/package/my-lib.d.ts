/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="my-lib" />
export * from './public-api';
